using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CodeSnippetManager.Views.Home
{
    public class AddSnippetModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
