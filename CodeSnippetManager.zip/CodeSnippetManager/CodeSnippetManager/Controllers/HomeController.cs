using CodeSnippetManager.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CodeSnippetManager.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private static List<CodeSnippet> snippets = new List<CodeSnippet>();

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Index: Display list of snippets
        public IActionResult Index()
        {
            return View(snippets);  // Pass snippets to the view
        }

        // Add a new snippet (GET)
        public IActionResult AddSnippet()
        {
            return View();
        }

        // Add a new snippet (POST)
        [HttpPost]
        public IActionResult AddSnippet(CodeSnippet snippet)
        {
            if (ModelState.IsValid)
            {
                snippet.Id = snippets.Count + 1;  // Set a new unique ID
                snippets.Add(snippet);  // Save snippet
                return RedirectToAction("Index");  // Redirect to index to show updated list
            }
            return View(snippet);
        }

        // Edit an existing snippet (GET)
        public IActionResult EditSnippet(int id)
        {
            var snippet = snippets.Find(s => s.Id == id);
            if (snippet != null)
            {
                return View(snippet);
            }
            return NotFound();
        }

        // Edit an existing snippet (POST)
        [HttpPost]
        public IActionResult EditSnippet(int id, CodeSnippet updatedSnippet)
        {
            var snippet = snippets.Find(s => s.Id == id);
            if (snippet != null)
            {
                snippet.Title = updatedSnippet.Title;
                snippet.Language = updatedSnippet.Language;
                snippet.Code = updatedSnippet.Code;
                snippet.Tags = updatedSnippet.Tags;
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        // Delete a snippet
        public IActionResult DeleteSnippet(int id)
        {
            var snippet = snippets.Find(s => s.Id == id);
            if (snippet != null)
            {
                snippets.Remove(snippet);
                return RedirectToAction("Index");
            }
            return NotFound();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
